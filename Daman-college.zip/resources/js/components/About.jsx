import React from 'react'

function About() {
  return (
    <div>
      <h2>thisi is ABout </h2>
    </div>
  )
}

export default About
