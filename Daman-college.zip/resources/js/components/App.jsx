import React from 'react'
import About from './About'
import Home from './Home'
import { NavLink, Router } from 'react-router-dom'
// import { NavLink } from 'react-router-dom'

const App = () => {
  return (
    <div>
      <h1>EHllo this heasding</h1>
      
        
        <NavLink to="/">
              Go to Home 
        </NavLink>
        <NavLink to="/about">
              Go to About
        </NavLink>
        <NavLink to="/*">
              <h1 className='text-3xl text-green-700'>Not Found Page</h1>
        </NavLink>
        
       
      
      <About/>
      <Home/>
      <Home/>
    </div>
  )
}

export default App
